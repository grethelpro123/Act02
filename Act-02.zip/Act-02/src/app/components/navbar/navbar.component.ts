import { Component } from '@angular/core';
import { InicioComponent } from '../inicio/inicio.component';
import { AcercadeComponent } from '../acercade/acercade.component';
@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrl: './navbar.component.css'
})
export class NavbarComponent {
}
